package dominio;

import java.util.ArrayList;
import java.util.List;


/* Classe que define o comportamento esperado de um Subject, que será "observado" pelos Assinantes */
public abstract class Subject {

    /**
     * Lista de assinantes de um Subject. O atributo é marcado como final para garantir que haja apenas UMA lista imutável.
     * */
    private final List<Assinante> assinantes = new ArrayList<>();


    public void adicionaAssinante(Assinante assinante) {
        this.assinantes.add(assinante);
        System.out.println("Assinante adicionado!");
    }

    public void removeAssinante(Assinante assinante) {
        this.assinantes.remove(assinante);
        System.out.println("Assinante removido!");
    }


    /**
     * Método que é considerado o "coração" do padrão Observer. É responsável por notificar seus assinantes caso uma determinada ação ocorra.
     * */
    public void notificaAssinantes(String produto, String estado) {
        for (Assinante assinante : this.assinantes) {
            assinante.notifica(produto, estado);
        }
    }
}
