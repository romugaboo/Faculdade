package dominio;


/* Subclasse que fará o papel de Assinante da aplicação */
public class Consumidor implements Assinante {

    private String nome;

    public Consumidor() { }

    public Consumidor(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * Implementação concreta do método responsável pela notificação quando algum processamento ocorre no Subject e que seja de interesse do Assinante
     * */
    @Override
    public void notifica(String produto, String estado) {
        System.out.println(this.nome + " O produto " + produto + " está " + estado + " !");
    }

    @Override
    public String toString() {
        return "Consumidor{" +
                "nome='" + nome + '\'' +
                '}';
    }
}
