package dominio;

public class HeadsetBomSubject extends Subject {
    private String state;
    private String modelo;

    public HeadsetBomSubject(String state, String modelo) {
        this.state = state;
        this.modelo = modelo;
    }

    public String getState() {
        return state;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public void setState(String state) {
        this.state = state;
        this.notificaAssinantes(this.modelo, this.state);

    }

    @Override
    public String toString() {
        return "HeadsetBomSubject{" +
                "state='" + state + '\'' +
                ", modelo='" + modelo + '\'' +
                '}';
    }
}
