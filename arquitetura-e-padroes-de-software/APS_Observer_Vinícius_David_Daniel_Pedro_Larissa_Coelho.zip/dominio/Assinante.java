package dominio;


/* Interface que define um comportamento esperado pelos Subscribers/Observers da aplicação */
public interface Assinante {

    /**
     * Método que define a notificação acionada por alguma ação do sistema e que é de interesse do Assinante
     * Aqui deixamos a implementação do método para a classe que implementa essa interface
     * */
    void notifica(String produto, String estado);
}
