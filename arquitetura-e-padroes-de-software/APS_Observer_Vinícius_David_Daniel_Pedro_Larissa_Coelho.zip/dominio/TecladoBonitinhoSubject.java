package dominio;

/*  Implementação concreta do Subject */
public class TecladoBonitinhoSubject extends Subject {

    /**
     * Atributos que caracterizam determinado produto, que poderá receber assinantes interessados em mudanças nesses objetos.
     * */
    private String state;
    private String modelo;

    public TecladoBonitinhoSubject(String state, String modelo) {
        this.state = state;
        this.modelo = modelo;
    }

    public String getState() {
        return state;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;

    }


    /**
     * Método responsável por notificar um cliente que esteja interessado em saber se esse produto está disponível.
     * Caso o "estado" tenha seu valor alterado, o metódo responsável por notificar os assinantes desse objeto serão notificados.
     * */
    public void setState(String state) {
        this.state = state;
        this.notificaAssinantes(this.modelo, this.state);
    }

    @Override
    public String toString() {
        return "TecladoBonitinhoSubject{" +
                "state='" + state + '\'' +
                ", modelo='" + modelo + '\'' +
                '}';
    }
}
