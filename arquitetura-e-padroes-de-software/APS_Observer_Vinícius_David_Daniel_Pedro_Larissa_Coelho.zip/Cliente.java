import dominio.*;

public class Cliente {
    public static void main(String[] args) {
        var headsetBom = new HeadsetBomSubject("Indiponível", "HyperX - Cloud Stinger 523");
        var tecladoBonitinho = new TecladoBonitinhoSubject("Esgotado", "Corsair - Bom pra Chuchu 123AX");

        Assinante consumidor1 = new Consumidor("Marcelo Areas");
        Assinante consumidor2 = new Consumidor("Larissa Coelho");
        Assinante consumidor3 = new Consumidor("Vinícius Alves");
        Assinante consumidor4 = new Consumidor("Daniel Pedro de Paula");
        Assinante consumidor5 = new Consumidor("Tia Cotinha");
        Assinante consumidor6 = new Consumidor("O ser Melancólico");
        Assinante consumidor7 = new Consumidor("Lobisomem Pidão");

        headsetBom.adicionaAssinante(consumidor1);
        headsetBom.adicionaAssinante(consumidor2);
        headsetBom.adicionaAssinante(consumidor3);
        headsetBom.adicionaAssinante(consumidor7);

        tecladoBonitinho.adicionaAssinante(consumidor4);
        tecladoBonitinho.adicionaAssinante(consumidor5);
        tecladoBonitinho.adicionaAssinante(consumidor6);
        tecladoBonitinho.adicionaAssinante(consumidor7);

        headsetBom.setState("Disponível");
        tecladoBonitinho.setState("Disponível");

        headsetBom.removeAssinante(consumidor2);
        tecladoBonitinho.removeAssinante(consumidor4);
        
        headsetBom.setState("NÃO TEM MAIS");
        tecladoBonitinho.setState("Indisponível");

    }
}