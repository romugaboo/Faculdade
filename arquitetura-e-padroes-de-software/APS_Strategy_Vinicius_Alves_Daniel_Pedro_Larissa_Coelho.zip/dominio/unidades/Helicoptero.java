package br.com.trabalho.strategy.dominio.unidades;

public class Helicoptero extends Unidade {

    public Helicoptero(int id) {
        super(id);
    }

    @Override
    public String toString() {
        return "Id: " + getId() + " Tipo: Helicóptero";
    }
}
