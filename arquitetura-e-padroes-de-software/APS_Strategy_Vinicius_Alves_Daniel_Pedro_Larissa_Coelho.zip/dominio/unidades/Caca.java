package br.com.trabalho.strategy.dominio.unidades;

public class Caca extends Unidade {

    public Caca(int id) {
        super(id);
    }

    @Override
    public String toString() {
        return "Id: " + getId() + " Tipo: Caça";
    }
}
