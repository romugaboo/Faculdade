package br.com.trabalho.strategy.dominio.unidades;

public class Obuseiro extends Unidade {

    public Obuseiro(int id) {
        super(id);
    }

    @Override
    public String toString() {
        return "Id: " + getId() + " Tipo: Obuseiro";
    }
}
