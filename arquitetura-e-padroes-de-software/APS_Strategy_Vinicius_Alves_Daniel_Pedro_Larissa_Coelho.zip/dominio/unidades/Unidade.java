package br.com.trabalho.strategy.dominio.unidades;

public abstract class Unidade {
    private int id;

    public Unidade(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
