package br.com.trabalho.strategy.dominio.unidades;

public class VeiculoLeve extends Unidade {

    public VeiculoLeve(int id) {
        super(id);
    }

    @Override
    public String toString() {
        return "Id: " + getId() + " Tipo: Veículo leve";
    }
}
