package br.com.trabalho.strategy.dominio.unidades;

public class CarroDeCombate extends Unidade {

    public CarroDeCombate(int id) {
        super(id);
    }

    @Override
    public String toString() {
        return "Id: " + getId() + " Tipo: Carro de combate";
    }
}
