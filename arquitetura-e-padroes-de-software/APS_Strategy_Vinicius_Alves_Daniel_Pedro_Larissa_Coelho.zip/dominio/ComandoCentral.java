package br.com.trabalho.strategy.dominio;

import br.com.trabalho.strategy.dominio.unidades.Unidade;
import br.com.trabalho.strategy.servico.Strategy;

import java.util.HashMap;
import java.util.Map;

public class ComandoCentral {

    private final Map<String, Unidade> unidades = new HashMap<>();

    private Strategy estrategia;

    public void setStrategy(Strategy estrategia) {
        this.estrategia = estrategia;
    }

    public void getStrategy() {

        if (this.estrategia == null) {
            System.out.println("Nenhuma estratégia foi adotada até o momento!");
            return;
        }

        System.out.println(this.estrategia);
    }

    public void comandaUnidade(Unidade u) {
        this.estrategia.executa(u);
    }

    public void insereUnidade(Unidade u) {
        System.out.println("Adicionando unidade " + u.toString() + " às suas forças!");
        unidades.put(String.valueOf(u.getId()), u);
    }

    public void removeUnidade(int idUnidade) {
        System.out.println("Removendo unidade " + idUnidade + " das suas forças!");

        if (unidades.remove(String.valueOf(idUnidade)) == null) {
            System.out.println("Unidade " + idUnidade + " não existia nas forças!");
        }
    }

    public Unidade getUnidade(int idUnidade) {
        var unidade = unidades.get(String.valueOf(idUnidade));

        if (unidade == null) {
            System.out.println("Essa unidade não existe!");
            return null;
        }

        return unidade;
    }

    public void listarUnidades() {
        for (var unidade : unidades.values()) {
            System.out.println(unidade.toString());
        }
    }
}
