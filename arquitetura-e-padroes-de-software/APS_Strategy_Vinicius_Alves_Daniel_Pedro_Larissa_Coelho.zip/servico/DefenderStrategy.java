package br.com.trabalho.strategy.servico;

import br.com.trabalho.strategy.dominio.unidades.Unidade;

public class DefenderStrategy implements Strategy {
    @Override
    public void executa(Unidade u) {

        if (u == null) {
            return;
        }

        System.out.println("Unidade " + u.getId() + "está defendendo!");
    }

    @Override
    public String toString() {
        return "Estratégia de Defesa";
    }
}
