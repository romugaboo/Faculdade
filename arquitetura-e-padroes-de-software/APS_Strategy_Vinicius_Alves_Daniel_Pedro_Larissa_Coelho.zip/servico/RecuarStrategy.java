package br.com.trabalho.strategy.servico;

import br.com.trabalho.strategy.dominio.unidades.Unidade;

public class RecuarStrategy implements Strategy {
    @Override
    public void executa(Unidade u) {

        if (u == null) {
            return;
        }

        System.out.println("Unidade " + u.getId() + "está recuando!");
    }

    @Override
    public String toString() {
        return "Estratégia de Recuo";
    }
}
