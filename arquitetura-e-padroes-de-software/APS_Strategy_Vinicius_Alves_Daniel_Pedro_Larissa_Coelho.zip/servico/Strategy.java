package br.com.trabalho.strategy.servico;

import br.com.trabalho.strategy.dominio.unidades.Unidade;

public interface Strategy {
    void executa(Unidade u);

}
