package br.com.trabalho.strategy;

import br.com.trabalho.strategy.dominio.ComandoCentral;
import br.com.trabalho.strategy.dominio.unidades.*;
import br.com.trabalho.strategy.servico.AtacarStrategy;
import br.com.trabalho.strategy.servico.DefenderStrategy;
import br.com.trabalho.strategy.servico.RecuarStrategy;

import java.util.Scanner;

public class Jogo {

    public static void main(String[] args) {

        ComandoCentral comandoCentral = new ComandoCentral();

        comandoCentral.insereUnidade(new Caca(1));
        comandoCentral.insereUnidade(new VeiculoLeve(2));
        comandoCentral.insereUnidade(new Helicoptero(3));
        comandoCentral.insereUnidade(new Obuseiro(4));
        comandoCentral.insereUnidade(new CarroDeCombate(5));
        comandoCentral.insereUnidade(new Obuseiro(6));
        comandoCentral.insereUnidade(new CarroDeCombate(7));
        comandoCentral.insereUnidade(new VeiculoLeve(8));
        comandoCentral.insereUnidade(new VeiculoLeve(9));

        System.out.println("\nO jogo começou!\n");

        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("------------------- Menu Estratégico -------------------");
            System.out.println("1 - Veja quais unidades você possui em suas forças.");
            System.out.println("2 - Adote uma determinada estratégia (atacar/defender/recuar).");
            System.out.println("3 - Veja qual estratégia está sendo utilizada.");
            System.out.println("4 - Dê um comando, de acordo com a estratégia adotada, para uma determinada unidade.");
            System.out.println("5 - Adicionar uma nova unidade às suas forças.");
            System.out.println("6 - Remover uma nova unidade das suas forças.");
            System.out.println("7 - Encerrar partida.");

            System.out.println("Escolha uma das opções: ");

            int opcaoSelecionada = sc.nextInt();
            sc.nextLine();

            switch (opcaoSelecionada) {
                case 1:
                    comandoCentral.listarUnidades();
                    break;

                case 2:
                    System.out.println("Escolha uma estratégia: ");
                    System.out.println("1 - Ataque");
                    System.out.println("2 - Defesa");
                    System.out.println("3 - Recuo");

                    int estrategiaSelecionada = sc.nextInt();
                    sc.nextLine();

                    switch (estrategiaSelecionada) {
                        case 1:
                            comandoCentral.setStrategy(new AtacarStrategy());
                            System.out.println("Estratégia de ataque selecionada!");
                            break;

                        case 2:
                            comandoCentral.setStrategy(new DefenderStrategy());
                            System.out.println("Estratégia de defesa selecionada!");
                            break;

                        case 3:
                            comandoCentral.setStrategy(new RecuarStrategy());
                            System.out.println("Estratégia de recuo selecionada!");
                            break;

                        default:
                            System.out.println("Escolha uma estratégia que exista né");
                    }
                    break;

                case 3:
                    System.out.println("Comando central está utilizando: ");
                    comandoCentral.getStrategy();
                    break;

                case 4:
                    System.out.println("Digite o id da unidade que deseja ordenar: ");
                    int idUnidade = sc.nextInt();
                    sc.nextLine();

                    var unidadeEscolhida = comandoCentral.getUnidade(idUnidade);

                    comandoCentral.comandaUnidade(unidadeEscolhida);

                    break;

                case 5:
                    System.out.println("Pegadinha do malandro! Você não pode adicionar unidades haha!");
                    break;

                case 6:
                    System.out.println("Pegadinha do malandro! Você não pode remover unidades haha!");
                    break;

                case 7:
                    System.out.println("Encerrando partida...");
                    System.exit(0);
            }


        }
    }
}
