package dominio;

public class Hamburguer {
    private String pao;
    private String carne;
    private String queijo;
    private String molho;
    private String salada;
    private String adicionais;

    public void setPao(String pao) {
        this.pao = pao;
    }

    public void setCarne(String carne) {
        this.carne = carne;
    }

    public void setQueijo(String queijo) {
        this.queijo = queijo;
    }

    public void setMolho(String molho) {
        this.molho = molho;
    }

    public void setSalada(String salada) {
        this.salada = salada;
    }

    public void setAdicionais(String adicionais) {
        this.adicionais = adicionais;
    }

    @Override
    public String toString() {
        return "Hamburguer{" +
                "pao='" + pao + '\'' +
                ", carne='" + carne + '\'' +
                ", queijo='" + queijo + '\'' +
                ", molho='" + molho + '\'' +
                ", salada='" + salada + '\'' +
                ", adicionais='" + adicionais + '\'' +
                '}';
    }
}
