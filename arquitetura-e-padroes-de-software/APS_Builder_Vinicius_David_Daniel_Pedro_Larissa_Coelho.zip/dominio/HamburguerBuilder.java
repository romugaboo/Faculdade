package dominio;

public interface HamburguerBuilder {
   void reset();
   HamburguerBuilder pao(String pao);
   HamburguerBuilder proteina(String proteina);
   HamburguerBuilder salada(String salada);
   HamburguerBuilder molho(String molho);
   HamburguerBuilder adicionais(String adicionais);
   Object build();
}
