package dominio;

public class HamburguerVeganoBuilder implements HamburguerBuilder {
    private HamburguerVegano hamburguerVegano;

    @Override
    public void reset() {
        System.out.println("Começando a montar o Hambúrguer Vegano...");
        hamburguerVegano = new HamburguerVegano();
    }

    @Override
    public HamburguerVeganoBuilder pao(String pao) {
        System.out.println("Fatiando o pão (" + pao + ") do Hambúrguer Vegano...");
        hamburguerVegano.setPao(pao);
        return this;
    }

    @Override
    public HamburguerVeganoBuilder proteina(String proteina) {
        System.out.println("Fritando a proteína (" + proteina + ") do Hambúrguer Vegano...");
        hamburguerVegano.setCarneVegetal(proteina);
        return this;
    }

    @Override
    public HamburguerVeganoBuilder salada(String salada) {
        System.out.println("Colocando a salada (" + salada + ") do Hambúrguer Vegano...");
        hamburguerVegano.setSalada(salada);
        return this;
    }

    @Override
    public HamburguerVeganoBuilder molho(String molho) {
        System.out.println("Colocando o molho (" + molho + ") do Hambúrguer Vegano...");
        hamburguerVegano.setMolho(molho);
        return this;
    }

    @Override
    public HamburguerVeganoBuilder adicionais(String adicionais) {
        System.out.println("Colocando os adicionais (" + adicionais + ") do Hambúrguer Vegano...");
        hamburguerVegano.setAdicionais(adicionais);
        return this;
    }

    @Override
    public HamburguerVegano build() {
        System.out.println("Hambúrguer Vegano montado! Que delícia!");
        System.out.println(hamburguerVegano.toString());
        return hamburguerVegano;
    }
}
