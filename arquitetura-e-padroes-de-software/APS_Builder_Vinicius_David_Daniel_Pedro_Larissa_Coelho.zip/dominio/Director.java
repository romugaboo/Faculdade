package dominio;

public class Director {

    private final HamburguerNormalBuilder hamburguerNormalBuilder;
    private final HamburguerVeganoBuilder hamburguerVeganoBuilder ;

    public Director(HamburguerNormalBuilder hamburguerNormalBuilder, HamburguerVeganoBuilder hamburguerVeganoBuilder) {
        this.hamburguerNormalBuilder = hamburguerNormalBuilder;
        this.hamburguerVeganoBuilder = hamburguerVeganoBuilder;
    }

    public Object montaHamburguer(Pedido pedido) {

        if (pedido.getTipoHamburguer().getCodigo() == 2) {
            hamburguerVeganoBuilder.reset();

            return hamburguerVeganoBuilder.pao(pedido.getPao())
                    .proteina(pedido.getProteina())
                    .molho(pedido.getMolho())
                    .salada(pedido.getSalada())
                    .adicionais(pedido.getAdicionais())
                    .build();
        }

        hamburguerNormalBuilder.reset();

        return hamburguerNormalBuilder.pao(pedido.getPao())
                .proteina(pedido.getProteina())
                .queijo(pedido.getQueijo())
                .molho(pedido.getMolho())
                .salada(pedido.getSalada())
                .adicionais(pedido.getAdicionais())
                .build();
    }

}
