package dominio;

public enum TipoHamburguer {
    HAMBURGUER(1, "Normal"),
    HAMBURGUER_VEGANO(2, "Vegano");

    private final int codigo;
    private final String nome;

    TipoHamburguer(int codigo, String nome) {
        this.codigo = codigo;
        this.nome = nome;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getNome() {
        return nome;
    }

    public static TipoHamburguer porCodigo(int codigo) {
        for (TipoHamburguer tipo : TipoHamburguer.values()) {
            if (tipo.getCodigo() == codigo) {
                return tipo;
            }
        }
        throw new IllegalArgumentException("Tipo de hambúrguer não encontrado para o código: " + codigo);
    }

    public static TipoHamburguer porNome(String nome) {
        for (TipoHamburguer tipo : TipoHamburguer.values()) {
            if (tipo.getNome().equalsIgnoreCase(nome)) {
                return tipo;
            }
        }
        throw new IllegalArgumentException("Tipo de hambúrguer não encontrado para o nome: " + nome);
    }
}
