package dominio;

public class HamburguerVegano {
    private String pao;
    private String carneVegetal;
    private String molho;
    private String salada;
    private String adicionais;

    public void setPao(String pao) {
        this.pao = pao;
    }

    public void setCarneVegetal(String carneVegetal) {
        this.carneVegetal = carneVegetal;
    }

    public void setMolho(String molho) {
        this.molho = molho;
    }

    public void setSalada(String salada) {
        this.salada = salada;
    }

    public void setAdicionais(String adicionais) {
        this.adicionais = adicionais;
    }

    @Override
    public String toString() {
        return "Hamburguer{" +
                "pao='" + pao + '\'' +
                ", carneVegetal='" + carneVegetal + '\'' +
                ", molho='" + molho + '\'' +
                ", salada='" + salada + '\'' +
                ", adicionais='" + adicionais + '\'' +
                '}';
    }
}
