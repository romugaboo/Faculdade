package dominio;

public class Pedido {
    private String pao;
    private String proteina;
    private String queijo;
    private String molho;
    private String salada;
    private String adicionais;
    private TipoHamburguer tipoHamburguer;

    public Pedido() {}

    public Pedido(String pao, String proteina, String queijo, String salada, String molho, String adicionais, TipoHamburguer tipoHamburguer) {
        this.pao = pao;
        this.tipoHamburguer = tipoHamburguer;
        this.salada = salada;
        this.adicionais = adicionais;
        this.molho = molho;
        this.queijo = queijo;
        this.proteina = proteina;
    }

    public String getPao() {
        return pao;
    }

    public void setPao(String pao) {
        this.pao = pao;
    }

    public String getProteina() {
        return proteina;
    }

    public void setProteina(String proteina) {
        this.proteina = proteina;
    }

    public String getQueijo() {
        return queijo;
    }

    public void setQueijo(String queijo) {
        this.queijo = queijo;
    }

    public String getMolho() {
        return molho;
    }

    public void setMolho(String molho) {
        this.molho = molho;
    }

    public String getSalada() {
        return salada;
    }

    public void setSalada(String salada) {
        this.salada = salada;
    }

    public String getAdicionais() {
        return adicionais;
    }

    public void setAdicionais(String adicionais) {
        this.adicionais = adicionais;
    }

    public TipoHamburguer getTipoHamburguer() {
        return tipoHamburguer;
    }

    public void setTipoHamburguer(TipoHamburguer tipoHamburguer) {
        this.tipoHamburguer = tipoHamburguer;
    }
}
