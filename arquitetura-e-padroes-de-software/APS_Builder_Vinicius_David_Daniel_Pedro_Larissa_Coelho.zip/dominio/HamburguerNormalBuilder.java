package dominio;

public class HamburguerNormalBuilder implements HamburguerBuilder {
    private Hamburguer hamburguerNormal;

    @Override
    public void reset() {
        System.out.println("Começando a montar o Hambúrguer Normal...");
        hamburguerNormal = new Hamburguer();
    }

    @Override
    public HamburguerNormalBuilder pao(String pao) {
        System.out.println("Fatiando o pão (" + pao + ") do Hambúrguer Normal...");
        hamburguerNormal.setPao(pao);
        return this;
    }

    @Override
    public HamburguerNormalBuilder proteina(String proteina) {
        System.out.println("Fritando a proteína (" + proteina + ") do Hambúrguer Normal...");
        hamburguerNormal.setCarne(proteina);
        return this;
    }

    public HamburguerNormalBuilder queijo(String queijo) {
        System.out.println("Colocando o queijo (" + queijo + ") do Hambúrguer Normal...");
        hamburguerNormal.setQueijo(queijo);
        return this;
    }

    @Override
    public HamburguerNormalBuilder salada(String salada) {
        System.out.println("Colocando a salada (" + salada + ") do Hambúrguer Normal...");
        hamburguerNormal.setSalada(salada);
        return this;
    }

    @Override
    public HamburguerNormalBuilder molho(String molho) {
        System.out.println("Colocando o molho (" + molho + ") do Hambúrguer Normal...");
        hamburguerNormal.setMolho(molho);
        return this;
    }

    @Override
    public HamburguerNormalBuilder adicionais(String adicionais) {
        System.out.println("Colocando os adicionais (" + adicionais + ") do Hambúrguer Normal...");
        hamburguerNormal.setAdicionais(adicionais);
        return this;
    }

    @Override
    public Hamburguer build() {
        System.out.println("Hambúrguer Normal montado! Que delícia!");
        System.out.println(hamburguerNormal.toString());
        return hamburguerNormal;
    }
}
