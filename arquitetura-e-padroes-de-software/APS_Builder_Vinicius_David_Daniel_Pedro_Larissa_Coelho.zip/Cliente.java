import dominio.*;

public class Cliente {
    public static void main(String[] args) {

        var director = new Director(new HamburguerNormalBuilder(), new HamburguerVeganoBuilder());

        Pedido pedido1 = new Pedido("Brioche", "Angus 180g", "Queijo Prato", "Barbecue", "Alface e Tomate", "Bacon", TipoHamburguer.HAMBURGUER);
        Pedido pedido2 = new Pedido("Australiano", "Wagyu 200g", "Queijo Mussarela",null ,"Maionese Verde", null, TipoHamburguer.HAMBURGUER);
        Pedido pedido3 = new Pedido("Gergelim", "Soja 190g", null, "Molho Rancho", "Alface, Tomate e Cebola", null, TipoHamburguer.HAMBURGUER_VEGANO);
        Pedido pedido4 = new Pedido("Brioche", "Shiitake 250g", null ,"Barbecue", "Alface e Tomate", "Houmus", TipoHamburguer.HAMBURGUER_VEGANO);

        var hamburguer1 = director.montaHamburguer(pedido1);
        var hamburguer2 = director.montaHamburguer(pedido2);
        var hamburguer3 = director.montaHamburguer(pedido3);
        var hamburguer4 = director.montaHamburguer(pedido4);
    }
}